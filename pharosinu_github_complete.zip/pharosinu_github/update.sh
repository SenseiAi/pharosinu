#!/bin/bash

# Update script for PharosInu Telegram Bot

echo "Updating PharosInu Telegram Bot..."

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "Git is not installed. Please install git first."
    exit 1
fi

# Check if we're in a git repository
if [ ! -d .git ]; then
    echo "This is not a git repository. Please run this script from the root of the PharosInu repository."
    exit 1
fi

# Save current directory
CURRENT_DIR=$(pwd)

# Pull latest changes
echo "Pulling latest changes from GitHub..."
git pull

# Check if pull was successful
if [ $? -ne 0 ]; then
    echo "Failed to pull latest changes. Please check your internet connection or repository permissions."
    exit 1
fi

# Install or update dependencies
echo "Installing/updating dependencies..."
pip install -r requirements.txt

# Check if systemd service exists
if [ -f /etc/systemd/system/pharosinu-bot.service ]; then
    echo "Restarting PharosInu bot service..."
    sudo systemctl restart pharosinu-bot
    echo "Checking service status..."
    sudo systemctl status pharosinu-bot
else
    echo "No systemd service found. If you want to run the bot as a service, please set it up."
    echo "You can start the bot manually with: ./start_bot.sh"
fi

echo "Update completed successfully!"
