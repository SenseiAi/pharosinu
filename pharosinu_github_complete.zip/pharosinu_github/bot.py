import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from dotenv import load_dotenv
import time

# Import managers
from wallet_manager import WalletManager
from mining_manager import MiningManager
from referral_manager import ReferralManager  # New import for referral system

# Import configuration
from config import (
    TELEGRAM_BOT_TOKEN,
    MINING_REWARD_AMOUNT,
    MINING_INTERVAL_SECONDS
)

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize managers
wallet_manager = WalletManager()
mining_manager = MiningManager(wallet_manager)
referral_manager = ReferralManager()  # Initialize the referral manager

# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a welcome message when the command /start is issued."""
    user = update.effective_user
    user_id = str(user.id)
    
    # Check if this is a referral
    if context.args and len(context.args) > 0:
        referral_code = context.args[0]
        success, message = referral_manager.add_referral(user_id, referral_code, user.username or user.first_name)
        if success:
            await update.message.reply_text(f"Welcome! You've been referred to PharosInu Mining Bot. {message}")
        else:
            await update.message.reply_text(f"Note: {message}")
    
    # Generate referral code for the user if they don't have one
    referral_code = referral_manager.get_user_referral_code(user_id)
    
    await update.message.reply_text(
        f"Hello {user.first_name}! Welcome to the PharosInu Mining Bot.\n\n"
        "This bot allows you to mine PharosInu tokens on the Pharos Testnet.\n\n"
        f"Your referral code: {referral_code}\n"
        f"Share this link to refer friends: https://t.me/YourBotUsername?start={referral_code}\n\n"
        "Commands:\n"
        "/createwallet - Create a new wallet\n"
        "/importwallet - Import an existing wallet\n"
        "/balance - Check your wallet balance\n"
        "/startmining - Start mining PharosInu tokens\n"
        "/mine - Mine PharosInu tokens\n"
        "/miningstats - View your mining statistics\n"
        "/transfer - Transfer PharosInu tokens\n"
        "/referral - View your referral code and basic stats\n"
        "/referralstats - View detailed referral statistics\n"
        "/topreferrers - View the referral leaderboard\n"
        "/help - Show this help message"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a help message when the command /help is issued."""
    await update.message.reply_text(
        "PharosInu Mining Bot Commands:\n\n"
        "/createwallet - Create a new wallet\n"
        "/importwallet - Import an existing wallet\n"
        "/balance - Check your wallet balance\n"
        "/startmining - Start mining PharosInu tokens\n"
        "/mine - Mine PharosInu tokens\n"
        "/miningstats - View your mining statistics\n"
        "/transfer - Transfer PharosInu tokens\n"
        "/referral - View your referral code and basic stats\n"
        "/referralstats - View detailed referral statistics\n"
        "/topreferrers - View the referral leaderboard\n"
        "/help - Show this help message"
    )

async def create_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Create a new wallet for the user."""
    user_id = str(update.effective_user.id)
    
    # Check if user already has a wallet
    existing_wallet = wallet_manager.get_wallet(user_id)
    if existing_wallet:
        await update.message.reply_text(
            "You already have a wallet. Your wallet address is:\n\n"
            f"`{existing_wallet['address']}`\n\n"
            "If you want to create a new wallet, please be aware that your old wallet will be overwritten.",
            parse_mode='Markdown'
        )
        return
    
    try:
        # Create new wallet
        wallet_info = wallet_manager.create_wallet(user_id)
        
        # Send response
        await update.message.reply_text(
            "✅ Wallet created successfully!\n\n"
            f"Address: `{wallet_info['address']}`\n\n"
            f"Private Key: `{wallet_info['private_key']}`\n\n"
            "⚠️ IMPORTANT: Save your private key in a secure location. "
            "It will be required if you need to restore your wallet. "
            "Never share your private key with anyone!",
            parse_mode='Markdown'
        )
    except Exception as e:
        logger.error(f"Error creating wallet: {str(e)}")
        await update.message.reply_text(f"Error creating wallet: {str(e)}")

async def import_wallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start the wallet import process."""
    await update.message.reply_text(
        "Please send your private key to import your wallet.\n\n"
        "⚠️ IMPORTANT: This should be done in a private chat only. "
        "Never share your private key with anyone else!"
    )
    context.user_data["awaiting_private_key"] = True

async def handle_private_key(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the private key sent by the user."""
    if context.user_data.get("awaiting_private_key"):
        user_id = str(update.effective_user.id)
        private_key = update.message.text.strip()
        
        try:
            # Import wallet
            wallet_info = wallet_manager.import_wallet(user_id, private_key)
            
            # Clear the awaiting flag
            context.user_data["awaiting_private_key"] = False
            
            # Send response
            await update.message.reply_text(
                "✅ Wallet imported successfully!\n\n"
                f"Address: `{wallet_info['address']}`",
                parse_mode='Markdown'
            )
            
            # Delete the message containing the private key for security
            await update.message.delete()
        except Exception as e:
            logger.error(f"Error importing wallet: {str(e)}")
            await update.message.reply_text(f"Error importing wallet: {str(e)}")
            context.user_data["awaiting_private_key"] = False

async def check_balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Check wallet balance."""
    user_id = str(update.effective_user.id)
    
    # Check if user has a wallet
    wallet_info = wallet_manager.get_wallet(user_id)
    if not wallet_info:
        await update.message.reply_text(
            "You don't have a wallet yet. Use /createwallet to create one or /importwallet to import an existing one."
        )
        return
    
    try:
        # Get balance
        balance = wallet_manager.check_balance(wallet_info['address'])
        
        # Send response
        await update.message.reply_text(
            f"Wallet Address: `{wallet_info['address']}`\n\n"
            f"PharosInu Balance: {balance['token']} PINU\n"
            f"Native Balance: {balance['native']} PHAR",
            parse_mode='Markdown'
        )
    except Exception as e:
        logger.error(f"Error checking balance: {str(e)}")
        await update.message.reply_text(f"Error checking balance: {str(e)}")

async def start_mining(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start mining PharosInu tokens."""
    user_id = str(update.effective_user.id)
    
    # Check if user already mining
    mining_data = mining_manager.get_mining_data(user_id)
    if mining_data:
        await update.message.reply_text(
            "You are already mining PharosInu tokens.\n\n"
            "Use /mine to collect your rewards or /miningstats to view your mining statistics."
        )
        return
    
    try:
        # Initialize mining
        mining_data = mining_manager.initialize_mining(user_id)
        
        # Send response
        hours, remainder = divmod(MINING_INTERVAL_SECONDS, 3600)
        minutes, _ = divmod(remainder, 60)
        time_str = ""
        if hours > 0:
            time_str += f"{int(hours)} hour{'s' if hours > 1 else ''} "
        if minutes > 0:
            time_str += f"{int(minutes)} minute{'s' if minutes > 1 else ''}"
        
        await update.message.reply_text(
            "✅ Mining started successfully!\n\n"
            f"You will earn {MINING_REWARD_AMOUNT} PINU tokens every {time_str}.\n\n"
            "Use /mine to collect your rewards when they are available."
        )
    except Exception as e:
        logger.error(f"Error starting mining: {str(e)}")
        await update.message.reply_text(f"Error starting mining: {str(e)}")

async def mine_tokens(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Mine PharosInu tokens."""
    user_id = str(update.effective_user.id)
    
    try:
        # Mine tokens
        result = mining_manager.mine(user_id)
        
        if result['success']:
            # Calculate referral reward if applicable
            referral_reward = 0
            if result['amount'] > 0:
                referral_reward = referral_manager.add_mining_reward(user_id, result['amount'])
            
            # Prepare response message
            response = f"⛏️ {result['message']}\n\n"
            response += f"Total mined: {result['total_mined']} PINU\n"
            response += f"Next mining available: {result['next_mining']}"
            
            # Add referral info if user was referred
            referrer_id = referral_manager.get_referrer(user_id)
            if referrer_id and referral_reward > 0:
                response += f"\n\nYour referrer earned {referral_reward:.2f} PINU from this mining operation."
            
            await update.message.reply_text(response)
        else:
            await update.message.reply_text(result['message'])
    except Exception as e:
        logger.error(f"Error mining tokens: {str(e)}")
        await update.message.reply_text(f"Error mining tokens: {str(e)}")

async def mining_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """View mining statistics."""
    user_id = str(update.effective_user.id)
    
    try:
        # Get mining stats
        stats = mining_manager.get_mining_stats(user_id)
        
        if stats['status'] == 'mining':
            await update.message.reply_text(
                "📊 Mining Statistics\n\n"
                f"Wallet Address: `{stats['address']}`\n"
                f"Total Mined: {stats['total_mined']} PINU\n"
                f"Mining Duration: {stats['mining_duration']}\n"
                f"Next Mining: {stats['next_mining']}",
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(stats['message'])
    except Exception as e:
        logger.error(f"Error getting mining stats: {str(e)}")
        await update.message.reply_text(f"Error getting mining stats: {str(e)}")

async def transfer_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start the token transfer process."""
    user_id = str(update.effective_user.id)
    
    # Check if user has a wallet
    wallet_info = wallet_manager.get_wallet(user_id)
    if not wallet_info:
        await update.message.reply_text(
            "You don't have a wallet yet. Use /createwallet to create one or /importwallet to import an existing one."
        )
        return
    
    await update.message.reply_text(
        "To transfer PharosInu tokens, please send a message in the following format:\n\n"
        "`/transfer <recipient_address> <amount>`\n\n"
        "Example: `/transfer 0x1234...5678 10`",
        parse_mode='Markdown'
    )

async def handle_transfer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle token transfer."""
    user_id = str(update.effective_user.id)
    
    # Check if user has a wallet
    wallet_info = wallet_manager.get_wallet(user_id)
    if not wallet_info:
        await update.message.reply_text(
            "You don't have a wallet yet. Use /createwallet to create one or /importwallet to import an existing one."
        )
        return
    
    # Parse arguments
    if len(context.args) != 2:
        await update.message.reply_text(
            "Invalid format. Please use:\n\n"
            "`/transfer <recipient_address> <amount>`\n\n"
            "Example: `/transfer 0x1234...5678 10`",
            parse_mode='Markdown'
        )
        return
    
    recipient = context.args[0]
    try:
        amount = float(context.args[1])
    except ValueError:
        await update.message.reply_text("Invalid amount. Please enter a valid number.")
        return
    
    try:
        # Transfer tokens
        result = wallet_manager.transfer_tokens(user_id, recipient, amount)
        
        if result['success']:
            await update.message.reply_text(
                "✅ Transfer successful!\n\n"
                f"From: `{result['from']}`\n"
                f"To: `{result['to']}`\n"
                f"Amount: {result['amount']} PINU\n"
                f"Transaction Hash: `{result['tx_hash']}`",
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(f"Transfer failed: {result.get('message', 'Unknown error')}")
    except Exception as e:
        logger.error(f"Error transferring tokens: {str(e)}")
        await update.message.reply_text(f"Error transferring tokens: {str(e)}")

# New referral-related commands
async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show user's referral code and basic stats."""
    user_id = str(update.effective_user.id)
    user = update.effective_user
    
    # Get or generate referral code
    referral_code = referral_manager.get_user_referral_code(user_id)
    
    # Get basic stats
    stats = referral_manager.get_referral_stats(user_id)
    
    # Create shareable link
    bot_username = await context.bot.get_me()
    share_link = f"https://t.me/{bot_username.username}?start={referral_code}"
    
    await update.message.reply_text(
        f"🔗 Your Referral Information\n\n"
        f"Referral Code: `{referral_code}`\n\n"
        f"Share this link with friends: {share_link}\n\n"
        f"Total Referrals: {stats['total_referrals']}\n"
        f"Total Rewards Earned: {stats['total_rewards']:.2f} PINU\n\n"
        "Use /referralstats for detailed statistics.",
        parse_mode='Markdown'
    )

async def referral_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show detailed referral statistics."""
    user_id = str(update.effective_user.id)
    
    # Get formatted stats
    formatted_stats = referral_manager.format_referral_stats(user_id)
    
    await update.message.reply_text(
        formatted_stats,
        parse_mode='Markdown'
    )

async def top_referrers_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show the referral leaderboard."""
    # Get formatted leaderboard
    formatted_leaderboard = referral_manager.format_leaderboard()
    
    await update.message.reply_text(
        formatted_leaderboard,
        parse_mode='Markdown'
    )

def main() -> None:
    """Start the bot."""
    # Create the Application
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("createwallet", create_wallet))
    application.add_handler(CommandHandler("importwallet", import_wallet_command))
    application.add_handler(CommandHandler("balance", check_balance))
    application.add_handler(CommandHandler("startmining", start_mining))
    application.add_handler(CommandHandler("mine", mine_tokens))
    application.add_handler(CommandHandler("miningstats", mining_stats))
    application.add_handler(CommandHandler("transfer", handle_transfer))
    
    # Add new referral command handlers
    application.add_handler(CommandHandler("referral", referral_command))
    application.add_handler(CommandHandler("referralstats", referral_stats_command))
    application.add_handler(CommandHandler("topreferrers", top_referrers_command))
    
    # Add message handler for private key
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_private_key))

    # Start the Bot
    application.run_polling()

if __name__ == '__main__':
    main()
