import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Telegram Bot Token
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

# Pharos Testnet Configuration
PHAROS_RPC_URL = "https://api.zan.top/node/v1/pharos/testnet/8d2017a632ac47b39bcfd6b05da0e4eb"
PHAROS_CHAIN_ID = 688688

# PharosInu Token Contract
TOKEN_CONTRACT_ADDRESS = "0x5215Ed6DCfcB7E6a3eD064a70d8152EdC0364580"

# Mining Configuration
MINING_REWARD_AMOUNT = 10  # Amount of tokens to reward per mining interval
MINING_INTERVAL_SECONDS = 3600  # 1 hour interval for mining rewards

# Default gas settings
GAS_LIMIT = 100000
GAS_PRICE = 1000000000  # 1 gwei
