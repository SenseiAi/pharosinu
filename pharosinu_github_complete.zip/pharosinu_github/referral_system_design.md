# PharosInu Telegram Bot - Referral System Design

## Overview
This document outlines the design for the referral system to be implemented in the PharosInu Telegram Mining Bot. The system will allow users to refer others, track referrals, and earn rewards based on their referrals' mining activities.

## Requirements
Based on user specifications:
1. Each user will have a unique referral code
2. Referrers will receive 1% of mining rewards from their referrals
3. Referral relationships will be permanent
4. Users will be able to see details of who they referred
5. Advanced features including leaderboards will be implemented
6. The project will be hosted on GitHub for easy VPS updates

## Data Structure

### Referral Data
We will add a new file `referral_manager.py` that will handle all referral-related functionality. The referral data will be stored in JSON files:

```
referral_data/
  ├── referral_codes.json  # Maps user_id to referral_code
  ├── referral_relationships.json  # Maps referred_user_id to referrer_user_id
  ├── referral_stats.json  # Tracks statistics for each user's referrals
  └── leaderboard.json  # Cached leaderboard data
```

### Data Models

#### Referral Code
```json
{
  "user_id": {
    "referral_code": "unique_code",
    "created_at": "timestamp"
  }
}
```

#### Referral Relationships
```json
{
  "referred_user_id": {
    "referrer_id": "user_id",
    "joined_at": "timestamp",
    "username": "telegram_username"
  }
}
```

#### Referral Statistics
```json
{
  "user_id": {
    "total_referrals": 0,
    "active_referrals": 0,
    "total_rewards": 0,
    "referred_users": [
      {
        "user_id": "referred_user_id",
        "username": "telegram_username",
        "joined_at": "timestamp",
        "mining_rewards_generated": 0
      }
    ]
  }
}
```

#### Leaderboard
```json
{
  "last_updated": "timestamp",
  "top_referrers": [
    {
      "user_id": "user_id",
      "username": "telegram_username",
      "total_referrals": 0,
      "total_rewards": 0
    }
  ]
}
```

## Functionality

### Referral Code Generation
- Generate a unique 8-character alphanumeric code for each user
- Store the mapping between user_id and referral_code
- Allow users to retrieve their referral code

### Referral Tracking
- When a new user joins and provides a referral code, validate the code
- If valid, establish a permanent referral relationship
- Update referral statistics for the referrer

### Reward Distribution
- When a referred user mines tokens, calculate 1% of the reward
- Add this amount to the referrer's balance
- Update the referral statistics

### User Interface
New commands to be added:
- `/referral` - Shows your referral code and basic stats
- `/referralstats` - Shows detailed stats about your referrals
- `/topreferrers` - Shows the leaderboard of top referrers
- `/start <referral_code>` - Modified start command to accept referral codes

### Leaderboard
- Periodically update a leaderboard of top referrers
- Sort by number of referrals and total rewards earned
- Display usernames (if available) or user IDs

## Integration with Existing System

### Mining Manager Integration
- Modify the `mine` function in `mining_manager.py` to check if the user was referred
- If referred, calculate and distribute the 1% reward to the referrer

### Wallet Manager Integration
- Add functionality to credit referral rewards to user wallets

### Bot Integration
- Add new command handlers for referral-related commands
- Modify the start command to accept referral codes

## GitHub Integration

### Repository Structure
```
pharosinu/
  ├── README.md
  ├── bot.py
  ├── config.py
  ├── mining_manager.py
  ├── wallet_manager.py
  ├── referral_manager.py  # New file
  ├── token_abi.json
  ├── start_bot.sh
  ├── requirements.txt
  ├── .gitignore
  └── docs/
      ├── setup.md
      └── usage.md
```

### Deployment Workflow
1. User clones the repository to their VPS
2. User sets up environment variables and dependencies
3. User runs the bot using the provided scripts
4. For updates, user pulls the latest changes from GitHub

### Update Script
We will provide a `update.sh` script that:
1. Pulls the latest changes from GitHub
2. Installs any new dependencies
3. Restarts the bot service

## Security Considerations
- Ensure referral codes are unique and not easily guessable
- Validate all user inputs to prevent injection attacks
- Implement proper error handling for all referral operations
- Ensure data persistence and backup for referral data

## Future Enhancements
- Tiered referral rewards based on number of referrals
- Time-limited referral campaigns with bonus rewards
- Referral milestones with special rewards
- Social media sharing of referral codes
