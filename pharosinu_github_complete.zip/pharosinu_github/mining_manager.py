import os
import time
import json
import logging
from datetime import datetime, timedelta

# Import wallet manager
from wallet_manager import WalletManager

# Import referral manager
from referral_manager import ReferralManager

# Import configuration
from config import (
    MINING_REWARD_AMOUNT,
    MINING_INTERVAL_SECONDS,
    TOKEN_CONTRACT_ADDRESS
)

class MiningManager:
    def __init__(self, wallet_manager, data_dir='mining_data'):
        """Initialize mining manager with wallet manager and data directory."""
        self.wallet_manager = wallet_manager
        self.referral_manager = ReferralManager()  # Initialize referral manager
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(data_dir, 'mining.log')),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger('MiningManager')
    
    def get_mining_data(self, user_id):
        """Get mining data for a user."""
        mining_path = os.path.join(self.data_dir, f"{user_id}.json")
        if not os.path.exists(mining_path):
            return None
        
        with open(mining_path, 'r') as f:
            return json.load(f)
    
    def initialize_mining(self, user_id):
        """Initialize mining for a user."""
        # Check if user has a wallet
        wallet_info = self.wallet_manager.get_wallet(user_id)
        if not wallet_info:
            raise ValueError("You need to create or import a wallet first")
        
        # Initialize mining data
        mining_data = {
            'user_id': user_id,
            'wallet_address': wallet_info['address'],
            'last_mined': None,
            'total_mined': 0,
            'mining_started': time.time()
        }
        
        # Save mining data
        mining_path = os.path.join(self.data_dir, f"{user_id}.json")
        with open(mining_path, 'w') as f:
            json.dump(mining_data, f)
        
        return mining_data
    
    def check_mining_status(self, user_id):
        """Check mining status for a user."""
        # Get mining data
        mining_data = self.get_mining_data(user_id)
        if not mining_data:
            return {
                'status': 'not_mining',
                'message': 'You are not mining yet. Use /startmining to start.'
            }
        
        # Check if user can mine now
        can_mine, time_left = self.can_mine(user_id)
        
        if can_mine:
            return {
                'status': 'ready',
                'message': 'You can mine now! Use /mine to collect your rewards.',
                'mining_data': mining_data
            }
        else:
            minutes, seconds = divmod(time_left, 60)
            return {
                'status': 'cooldown',
                'message': f'Mining cooldown in progress. You can mine again in {int(minutes)}m {int(seconds)}s.',
                'time_left': time_left,
                'mining_data': mining_data
            }
    
    def can_mine(self, user_id):
        """Check if a user can mine now."""
        mining_data = self.get_mining_data(user_id)
        if not mining_data:
            return False, 0
        
        # If never mined before, can mine immediately
        if not mining_data.get('last_mined'):
            return True, 0
        
        # Calculate time since last mining
        last_mined = mining_data['last_mined']
        current_time = time.time()
        time_passed = current_time - last_mined
        
        # Check if enough time has passed
        if time_passed >= MINING_INTERVAL_SECONDS:
            return True, 0
        else:
            time_left = MINING_INTERVAL_SECONDS - time_passed
            return False, time_left
    
    def mine(self, user_id):
        """Mine tokens for a user."""
        # Check if user can mine
        can_mine, time_left = self.can_mine(user_id)
        if not can_mine:
            minutes, seconds = divmod(time_left, 60)
            return {
                'success': False,
                'message': f'Mining cooldown in progress. You can mine again in {int(minutes)}m {int(seconds)}s.',
                'amount': 0
            }
        
        # Get mining data
        mining_data = self.get_mining_data(user_id)
        if not mining_data:
            return {
                'success': False,
                'message': 'You need to start mining first. Use /startmining.',
                'amount': 0
            }
        
        # Update mining data
        mining_data['last_mined'] = time.time()
        mining_data['total_mined'] += MINING_REWARD_AMOUNT
        
        # Save updated mining data
        mining_path = os.path.join(self.data_dir, f"{user_id}.json")
        with open(mining_path, 'w') as f:
            json.dump(mining_data, f)
        
        # Log mining activity
        self.logger.info(f"User {user_id} mined {MINING_REWARD_AMOUNT} PINU tokens")
        
        # Check for referral relationship and process referral reward
        referrer_id = self.referral_manager.get_referrer(user_id)
        if referrer_id:
            # Calculate 1% referral reward
            referral_reward = MINING_REWARD_AMOUNT * 0.01
            
            # Add the reward to the referrer's wallet
            try:
                referrer_wallet = self.wallet_manager.get_wallet(referrer_id)
                if referrer_wallet:
                    # In a real implementation, we would transfer tokens here
                    # For this demo, we'll just log it
                    self.logger.info(f"Referral reward of {referral_reward} PINU sent to user {referrer_id}")
                    
                    # Update referral statistics
                    self.referral_manager.add_mining_reward(user_id, MINING_REWARD_AMOUNT)
            except Exception as e:
                self.logger.error(f"Error processing referral reward: {str(e)}")
        
        # In a real implementation, we would transfer tokens here
        # For this demo, we'll just simulate it
        
        return {
            'success': True,
            'message': f'Successfully mined {MINING_REWARD_AMOUNT} PINU tokens!',
            'amount': MINING_REWARD_AMOUNT,
            'total_mined': mining_data['total_mined'],
            'next_mining': datetime.fromtimestamp(mining_data['last_mined'] + MINING_INTERVAL_SECONDS).strftime('%Y-%m-%d %H:%M:%S')
        }
    
    def get_mining_stats(self, user_id):
        """Get mining statistics for a user."""
        mining_data = self.get_mining_data(user_id)
        if not mining_data:
            return {
                'status': 'not_mining',
                'message': 'You are not mining yet. Use /startmining to start.'
            }
        
        # Calculate mining statistics
        current_time = time.time()
        mining_duration = current_time - mining_data.get('mining_started', current_time)
        days, remainder = divmod(mining_duration, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        # Format duration
        duration_str = ''
        if days > 0:
            duration_str += f"{int(days)} days, "
        if hours > 0 or days > 0:
            duration_str += f"{int(hours)} hours, "
        duration_str += f"{int(minutes)} minutes"
        
        # Get next mining time
        next_mining_time = None
        if mining_data.get('last_mined'):
            next_mining_time = mining_data['last_mined'] + MINING_INTERVAL_SECONDS
            if next_mining_time < current_time:
                next_mining_time = "Available now!"
            else:
                next_mining_time = datetime.fromtimestamp(next_mining_time).strftime('%Y-%m-%d %H:%M:%S')
        else:
            next_mining_time = "Available now!"
        
        # Get referral information
        referrer_id = self.referral_manager.get_referrer(user_id)
        referral_info = ""
        if referrer_id:
            referral_info = f"You were referred by user ID: {referrer_id}"
        
        # Get referral stats
        referral_stats = self.referral_manager.get_referral_stats(user_id)
        
        return {
            'status': 'mining',
            'address': mining_data['wallet_address'],
            'total_mined': mining_data['total_mined'],
            'mining_duration': duration_str,
            'next_mining': next_mining_time,
            'referrer': referrer_id,
            'referral_count': referral_stats['total_referrals'],
            'referral_rewards': referral_stats['total_rewards']
        }
