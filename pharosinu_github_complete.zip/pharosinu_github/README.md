# PharosInu Telegram Bot - User Guide

## Overview
This project consists of two main components:
1. **PharosInu Token Contract** - An ERC20 token deployed on the Pharos Testnet with ShibaInu-like tokenomics
2. **Telegram Mining Bot** - A bot that allows users to mine PharosInu tokens through time-based rewards

## PharosInu Token Details
- **Name**: PharosInu
- **Symbol**: PINU
- **Total Supply**: 1,000,000,000 (1 billion)
- **Contract Address**: 0x5215Ed6DCfcB7E6a3eD064a70d8152EdC0364580
- **Network**: Pharos Testnet
- **RPC URL**: https://api.zan.top/node/v1/pharos/testnet/8d2017a632ac47b39bcfd6b05da0e4eb
- **Chain ID**: 688688

### Tokenomics
- 1% burn fee on each transaction
- 1% redistribution fee on each transaction
- Owner can exclude addresses from fees (for exchange listings, etc.)
- Owner can update fee percentages and fee collector address

## Telegram Bot Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- A Telegram bot token (obtained from BotFather)

### Installation
1. Clone the repository:
   ```
   git clone https://github.com/yourusername/pharosinu.git
   cd pharosinu
   ```

2. Install dependencies:
   ```
   pip install python-telegram-bot web3 python-dotenv
   ```

3. Create a `.env` file with your Telegram bot token:
   ```
   TELEGRAM_BOT_TOKEN=your_bot_token_here
   ```

4. Run the bot:
   ```
   ./start_bot.sh
   ```
   or
   ```
   python bot.py
   ```

### Updating the Bot
To update the bot with the latest changes from GitHub:
```
./update.sh
```

## Bot Commands

### Basic Commands
- `/start` - Welcome message and command list
- `/help` - Show available commands

### Wallet Management
- `/createwallet` - Create a new wallet
- `/importwallet` - Import an existing wallet using private key
- `/balance` - Check your wallet balance
- `/transfer <address> <amount>` - Transfer tokens to another address

### Mining
- `/startmining` - Start mining PharosInu tokens
- `/mine` - Mine PharosInu tokens (when available)
- `/miningstats` - View your mining statistics

### Referral System
- `/referral` - View your referral code and basic stats
- `/referralstats` - View detailed statistics about your referrals
- `/topreferrers` - View the leaderboard of top referrers

## Mining Mechanism
The mining mechanism is time-based:
- Users can mine 10 PINU tokens every hour
- Mining rewards are tracked per user
- Users must manually claim rewards using the `/mine` command
- Mining statistics can be viewed with the `/miningstats` command

## Referral System
The bot includes a comprehensive referral system:
- Each user gets a unique 8-character referral code
- Users can refer others by sharing their code or referral link
- Referrers earn 1% of all mining rewards from users they referred
- Referral relationships are permanent
- Users can see details of who they referred
- A leaderboard shows the top referrers

### How to Refer Others
1. Get your referral code using the `/referral` command
2. Share your referral link with friends
3. When they start the bot using your link, they'll be automatically referred to you
4. Alternatively, they can use the `/start YOUR_CODE` command

### Referral Rewards
- You earn 1% of all mining rewards from users you referred
- Rewards are automatically added to your balance
- View your total referral rewards with `/referralstats`

## Security Notes
- Private keys are stored locally in the bot's data directory
- Users should save their private keys securely
- The bot deletes messages containing private keys for security
- All wallet operations are performed client-side

## Customization
You can customize the mining rewards and intervals by editing the `config.py` file:
- `MINING_REWARD_AMOUNT` - Amount of tokens to reward per mining interval
- `MINING_INTERVAL_SECONDS` - Time interval between mining rewards

## Project Structure
- `bot.py` - Main Telegram bot code
- `wallet_manager.py` - Wallet management functionality
- `mining_manager.py` - Mining logic and rewards
- `referral_manager.py` - Referral system functionality
- `config.py` - Configuration settings
- `token_abi.json` - ABI for interacting with the token contract
- `start_bot.sh` - Script to start the bot
- `update.sh` - Script to update the bot from GitHub

## Troubleshooting
- If the bot doesn't respond, check that your bot token is correct
- If mining doesn't work, ensure the contract address in config.py is correct
- For wallet issues, check that the Pharos RPC URL is accessible
- For transfer issues, ensure the wallet has enough tokens and gas
- If referral rewards aren't being distributed, check the referral relationship in the logs
