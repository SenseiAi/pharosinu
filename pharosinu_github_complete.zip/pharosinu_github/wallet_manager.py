import os
import json
import time
from web3 import Web3
from eth_account import Account
import secrets

# Import configuration
from config import (
    PHAROS_RPC_URL,
    PHAROS_CHAIN_ID,
    TOKEN_CONTRACT_ADDRESS,
    GAS_LIMIT,
    GAS_PRICE
)

# Connect to Pharos Testnet
w3 = Web3(Web3.HTTPProvider(PHAROS_RPC_URL))

# Load token ABI
with open('token_abi.json', 'r') as f:
    token_abi = json.load(f)

# Initialize token contract
token_contract = w3.eth.contract(address=TOKEN_CONTRACT_ADDRESS, abi=token_abi)

class WalletManager:
    def __init__(self, data_dir='wallets'):
        """Initialize wallet manager with data directory for storing wallet files."""
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
    
    def create_wallet(self, user_id):
        """Create a new wallet for a user."""
        # Generate a random private key
        private_key = "0x" + secrets.token_hex(32)
        account = Account.from_key(private_key)
        
        # Store wallet info
        wallet_info = {
            'address': account.address,
            'private_key': private_key,
            'created_at': time.time()
        }
        
        # Save to file
        wallet_path = os.path.join(self.data_dir, f"{user_id}.json")
        with open(wallet_path, 'w') as f:
            json.dump(wallet_info, f)
        
        return wallet_info
    
    def import_wallet(self, user_id, private_key):
        """Import an existing wallet using private key."""
        try:
            # Ensure private key has 0x prefix
            if not private_key.startswith('0x'):
                private_key = '0x' + private_key
                
            account = Account.from_key(private_key)
            
            # Store wallet info
            wallet_info = {
                'address': account.address,
                'private_key': private_key,
                'imported_at': time.time()
            }
            
            # Save to file
            wallet_path = os.path.join(self.data_dir, f"{user_id}.json")
            with open(wallet_path, 'w') as f:
                json.dump(wallet_info, f)
            
            return wallet_info
        except Exception as e:
            raise ValueError(f"Invalid private key: {str(e)}")
    
    def get_wallet(self, user_id):
        """Get wallet info for a user."""
        wallet_path = os.path.join(self.data_dir, f"{user_id}.json")
        if not os.path.exists(wallet_path):
            return None
        
        with open(wallet_path, 'r') as f:
            return json.load(f)
    
    def check_balance(self, address):
        """Check token balance for an address."""
        try:
            # Get native token balance (ETH/PHAR)
            native_balance = w3.eth.get_balance(address)
            native_balance_eth = w3.from_wei(native_balance, 'ether')
            
            # Get PharosInu token balance
            token_balance = token_contract.functions.balanceOf(address).call()
            token_balance_formatted = token_balance / 10**18  # Assuming 18 decimals
            
            return {
                'native': native_balance_eth,
                'token': token_balance_formatted
            }
        except Exception as e:
            raise ValueError(f"Error checking balance: {str(e)}")
    
    def transfer_tokens(self, user_id, to_address, amount):
        """Transfer tokens from user's wallet to another address."""
        wallet_info = self.get_wallet(user_id)
        if not wallet_info:
            raise ValueError("Wallet not found")
        
        try:
            # Convert amount to wei (assuming 18 decimals)
            amount_wei = int(amount * 10**18)
            
            # Get nonce
            nonce = w3.eth.get_transaction_count(wallet_info['address'])
            
            # Build transaction
            tx = token_contract.functions.transfer(
                to_address,
                amount_wei
            ).build_transaction({
                'chainId': PHAROS_CHAIN_ID,
                'gas': GAS_LIMIT,
                'gasPrice': GAS_PRICE,
                'nonce': nonce,
            })
            
            # Sign transaction
            signed_tx = w3.eth.account.sign_transaction(tx, wallet_info['private_key'])
            
            # Send transaction
            tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)
            
            # Wait for transaction receipt
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
            
            return {
                'success': receipt.status == 1,
                'tx_hash': tx_hash.hex(),
                'from': wallet_info['address'],
                'to': to_address,
                'amount': amount
            }
        except Exception as e:
            raise ValueError(f"Error transferring tokens: {str(e)}")
