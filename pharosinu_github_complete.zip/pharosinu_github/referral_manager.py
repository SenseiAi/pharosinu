import os
import json
import time
import random
import string
import logging
from datetime import datetime

class ReferralManager:
    def __init__(self, data_dir='referral_data'):
        """Initialize referral manager with data directory."""
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(data_dir, 'referral.log')),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger('ReferralManager')
        
        # Initialize data files
        self.referral_codes_file = os.path.join(data_dir, 'referral_codes.json')
        self.relationships_file = os.path.join(data_dir, 'referral_relationships.json')
        self.stats_file = os.path.join(data_dir, 'referral_stats.json')
        self.leaderboard_file = os.path.join(data_dir, 'leaderboard.json')
        
        # Load or create data files
        self._load_or_create_data()
    
    def _load_or_create_data(self):
        """Load existing data or create new data files."""
        # Referral codes
        if os.path.exists(self.referral_codes_file):
            with open(self.referral_codes_file, 'r') as f:
                self.referral_codes = json.load(f)
        else:
            self.referral_codes = {}
            self._save_referral_codes()
        
        # Referral relationships
        if os.path.exists(self.relationships_file):
            with open(self.relationships_file, 'r') as f:
                self.relationships = json.load(f)
        else:
            self.relationships = {}
            self._save_relationships()
        
        # Referral statistics
        if os.path.exists(self.stats_file):
            with open(self.stats_file, 'r') as f:
                self.stats = json.load(f)
        else:
            self.stats = {}
            self._save_stats()
        
        # Leaderboard
        if os.path.exists(self.leaderboard_file):
            with open(self.leaderboard_file, 'r') as f:
                self.leaderboard = json.load(f)
        else:
            self.leaderboard = {
                "last_updated": time.time(),
                "top_referrers": []
            }
            self._save_leaderboard()
    
    def _save_referral_codes(self):
        """Save referral codes to file."""
        with open(self.referral_codes_file, 'w') as f:
            json.dump(self.referral_codes, f, indent=2)
    
    def _save_relationships(self):
        """Save referral relationships to file."""
        with open(self.relationships_file, 'w') as f:
            json.dump(self.relationships, f, indent=2)
    
    def _save_stats(self):
        """Save referral statistics to file."""
        with open(self.stats_file, 'w') as f:
            json.dump(self.stats, f, indent=2)
    
    def _save_leaderboard(self):
        """Save leaderboard to file."""
        with open(self.leaderboard_file, 'w') as f:
            json.dump(self.leaderboard, f, indent=2)
    
    def _generate_referral_code(self):
        """Generate a unique 8-character alphanumeric referral code."""
        while True:
            # Generate a random 8-character code
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            
            # Check if code already exists
            if not any(data.get('referral_code') == code for data in self.referral_codes.values()):
                return code
    
    def get_user_referral_code(self, user_id):
        """Get or create a referral code for a user."""
        user_id = str(user_id)
        
        # Check if user already has a referral code
        if user_id in self.referral_codes:
            return self.referral_codes[user_id]['referral_code']
        
        # Generate a new referral code
        code = self._generate_referral_code()
        
        # Store the new code
        self.referral_codes[user_id] = {
            'referral_code': code,
            'created_at': time.time()
        }
        self._save_referral_codes()
        
        # Initialize stats for the user
        if user_id not in self.stats:
            self.stats[user_id] = {
                'total_referrals': 0,
                'active_referrals': 0,
                'total_rewards': 0,
                'referred_users': []
            }
            self._save_stats()
        
        return code
    
    def get_referrer_by_code(self, referral_code):
        """Get the user ID of the referrer based on referral code."""
        for user_id, data in self.referral_codes.items():
            if data.get('referral_code') == referral_code:
                return user_id
        return None
    
    def add_referral(self, referred_user_id, referral_code, username=None):
        """Add a new referral relationship."""
        referred_user_id = str(referred_user_id)
        
        # Check if user is already referred
        if referred_user_id in self.relationships:
            return False, "You have already been referred by someone."
        
        # Get referrer ID from code
        referrer_id = self.get_referrer_by_code(referral_code)
        if not referrer_id:
            return False, "Invalid referral code."
        
        # Prevent self-referral
        if referred_user_id == referrer_id:
            return False, "You cannot refer yourself."
        
        # Create the referral relationship
        self.relationships[referred_user_id] = {
            'referrer_id': referrer_id,
            'joined_at': time.time(),
            'username': username or referred_user_id
        }
        self._save_relationships()
        
        # Update referrer stats
        if referrer_id not in self.stats:
            self.stats[referrer_id] = {
                'total_referrals': 0,
                'active_referrals': 0,
                'total_rewards': 0,
                'referred_users': []
            }
        
        self.stats[referrer_id]['total_referrals'] += 1
        self.stats[referrer_id]['active_referrals'] += 1
        self.stats[referrer_id]['referred_users'].append({
            'user_id': referred_user_id,
            'username': username or referred_user_id,
            'joined_at': time.time(),
            'mining_rewards_generated': 0
        })
        self._save_stats()
        
        # Update leaderboard
        self.update_leaderboard()
        
        return True, f"Successfully referred by user with ID {referrer_id}."
    
    def get_referrer(self, user_id):
        """Get the referrer of a user."""
        user_id = str(user_id)
        if user_id in self.relationships:
            return self.relationships[user_id]['referrer_id']
        return None
    
    def get_referral_stats(self, user_id):
        """Get referral statistics for a user."""
        user_id = str(user_id)
        if user_id in self.stats:
            return self.stats[user_id]
        return {
            'total_referrals': 0,
            'active_referrals': 0,
            'total_rewards': 0,
            'referred_users': []
        }
    
    def add_mining_reward(self, user_id, amount):
        """Add mining reward to referrer if user was referred."""
        user_id = str(user_id)
        referrer_id = self.get_referrer(user_id)
        
        if not referrer_id:
            return 0  # User was not referred
        
        # Calculate 1% reward
        reward_amount = amount * 0.01
        
        # Update referrer stats
        if referrer_id in self.stats:
            self.stats[referrer_id]['total_rewards'] += reward_amount
            
            # Update the specific referred user's contribution
            for referred_user in self.stats[referrer_id]['referred_users']:
                if referred_user['user_id'] == user_id:
                    referred_user['mining_rewards_generated'] += reward_amount
                    break
            
            self._save_stats()
        
        # Update leaderboard
        self.update_leaderboard()
        
        return reward_amount
    
    def update_leaderboard(self):
        """Update the referral leaderboard."""
        # Sort users by total referrals
        sorted_users = sorted(
            self.stats.items(),
            key=lambda x: (x[1]['total_referrals'], x[1]['total_rewards']),
            reverse=True
        )
        
        # Take top 10
        top_referrers = []
        for user_id, stats in sorted_users[:10]:
            # Get username if available
            username = user_id
            for referred_id, rel_data in self.relationships.items():
                if rel_data['referrer_id'] == user_id and rel_data.get('username'):
                    username = rel_data.get('username')
                    break
            
            top_referrers.append({
                'user_id': user_id,
                'username': username,
                'total_referrals': stats['total_referrals'],
                'total_rewards': stats['total_rewards']
            })
        
        # Update leaderboard
        self.leaderboard = {
            'last_updated': time.time(),
            'top_referrers': top_referrers
        }
        self._save_leaderboard()
    
    def get_leaderboard(self):
        """Get the current leaderboard."""
        # Check if leaderboard needs updating (older than 1 hour)
        if time.time() - self.leaderboard['last_updated'] > 3600:
            self.update_leaderboard()
        
        return self.leaderboard
    
    def format_referral_stats(self, user_id):
        """Format referral statistics for display."""
        user_id = str(user_id)
        stats = self.get_referral_stats(user_id)
        code = self.get_user_referral_code(user_id)
        
        result = f"📊 Your Referral Statistics\n\n"
        result += f"🔑 Your Referral Code: {code}\n"
        result += f"👥 Total Referrals: {stats['total_referrals']}\n"
        result += f"💰 Total Rewards Earned: {stats['total_rewards']:.2f} PINU\n\n"
        
        if stats['referred_users']:
            result += "👤 Your Referrals:\n"
            for i, user in enumerate(stats['referred_users'], 1):
                joined_date = datetime.fromtimestamp(user['joined_at']).strftime('%Y-%m-%d')
                result += f"{i}. {user['username']} (joined: {joined_date})\n"
                result += f"   Generated: {user['mining_rewards_generated']:.2f} PINU in rewards for you\n"
        else:
            result += "You haven't referred anyone yet. Share your referral code to start earning rewards!"
        
        return result
    
    def format_leaderboard(self):
        """Format leaderboard for display."""
        leaderboard = self.get_leaderboard()
        
        result = "🏆 Top Referrers Leaderboard 🏆\n\n"
        
        if not leaderboard['top_referrers']:
            return result + "No referrals yet. Be the first to refer someone!"
        
        for i, entry in enumerate(leaderboard['top_referrers'], 1):
            result += f"{i}. {entry['username']}\n"
            result += f"   👥 Referrals: {entry['total_referrals']}\n"
            result += f"   💰 Rewards: {entry['total_rewards']:.2f} PINU\n"
        
        last_updated = datetime.fromtimestamp(leaderboard['last_updated']).strftime('%Y-%m-%d %H:%M:%S')
        result += f"\nLast updated: {last_updated}"
        
        return result
