#!/bin/bash

# This script starts the PharosInu Telegram Mining Bot

# Check if .env file exists
if [ ! -f .env ]; then
  echo "Creating .env file..."
  echo "TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN_HERE" > .env
  echo "Please edit the .env file and add your Telegram bot token."
  exit 1
fi

# Start the bot
echo "Starting PharosInu Telegram Mining Bot..."
python3 bot.py
